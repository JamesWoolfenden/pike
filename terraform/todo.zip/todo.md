aws_lambda
aws_api_gateway_rest_api
aws_apigatewayv2_api
aws_launch_config
aws_autoscaling_group
aws_cloudtrail
aws_cloudwatch_log_group
aws_codebuild
aws_codecommit
aws_codedeploy
aws_codepipeline
aws_cognito_identity_pool
aws_dynamodb_table

aws_ebs_volume
aws_ami
aws_eip
aws_key_pair
aws_launch_template
aws_lb
aws_lb_listener
aws_lb_target_group

aws_kms_key
aws_db_instance
aws_route53_record
aws_route53_zone
sqs
sns

nacl
vpc
subnet
route_table
nat_gateway

handle 
2022/07/24 07:00:37 data aws_caller_identity not found
2022/07/24 07:00:37 provider aws not found

